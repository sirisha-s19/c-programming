#include<stdio.h>
int main()
{
    int a[100],i,n,sum=0;
    printf("enter the value of n \n");
    scanf("%d",&n);
    printf("enter the array elements \n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    {
        sum=sum+a[i];
    }
    printf("sum of array elements=%d",sum);
    return 0;
}